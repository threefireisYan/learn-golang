package linking

// APIHost 指定了 API 服务器的地址
var APIHost = "linking.qiniuapi.com/v1"

// APIHTTPScheme 指定了在请求 API 服务器时使用的 HTTP 模式.
var APIHTTPScheme = "http://"
