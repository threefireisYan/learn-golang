// cdn 包提供了 Fusion CDN的常见功能。相关功能的文档参考：https://developer.qiniu.com/fusion。
// 目前提供了文件和目录刷新，文件预取，获取域名带宽和流量数据，获取域名日志列表等功能。
package cdn
